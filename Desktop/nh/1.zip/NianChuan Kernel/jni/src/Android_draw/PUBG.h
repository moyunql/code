AimCount = 0;
lunxian.PlayerCount = 0;
lunxian.BotCount = 0;

// 游戏数据一系列
lunxian.Uworld = driver->read<uintptr_t>(driver->read<uintptr_t>(driver->read<uintptr_t>(lunxian.libUE4 + 0xE370A98) + 0x810) + 0x78); // 游戏世界  他这里有4层，我就按照他的4层来写了 不知道这个有没有影响自瞄
lunxian.Gname = driver->read<uintptr_t>(driver->read<uintptr_t>(lunxian.libUE4 + 0xDD879E0) + 0x110);
lunxian.Uleve = driver->read<uintptr_t>(lunxian.Uworld + 0x30);
lunxian.Arrayaddr = driver->read<uintptr_t>(lunxian.Uleve + 0xA0);
lunxian.Count = driver->read<int>(lunxian.Uleve + 0xA8);

// 自身一系类
lunxian.Oneself = driver->read<uintptr_t>(driver->read<uintptr_t>(driver->read<uintptr_t>(driver->read<uintptr_t>(driver->read<uintptr_t>(driver->read<uintptr_t>(driver->read<uintptr_t>(lunxian.libUE4 + 0xDE49DE8) +0x810) + 0x78) + 0x38) + 0x78) + 0x30) + 0x2698);  // 自身对象;
lunxian.MyTeam = driver->read<int>(lunxian.Oneself + 0x928);
//lunxian.MyWeapon = driver->read<uintptr_t>(driver->read<uintptr_t>(driver->read<uintptr_t>(driver->read<uintptr_t>(lunxian.Oneself + 0x2328) + 0x558) + 0x840) + 0x178);
driver->read(driver->read<uintptr_t>(lunxian.Oneself + 0x1b0) + 0x1c0, &lunxian.MyPos, 12);
driver->read(lunxian.Matrixs, &lunxian.matrix, 16 * 4);

lunxian.Fov = driver->read<float>(driver->read<uintptr_t>(driver->read<uintptr_t>(lunxian.libUE4 + 0xDEBF960) + 0x108) + 0x4E4);   // 自身FOV   身加+？

lunxian.IsFiring = driver->read<int>(lunxian.Oneself + 0x16d0);//开火
lunxian.IsAiming = driver->read<int>(lunxian.Oneself + 0x1069);//开镜
// lunxian.angle = driver->read<float>(lunxian.Oneself + 0xd8) - 90; 



char *CasName;

for (int i = 0; i < lunxian.Count; i ++) {
lunxian.Objaddr = driver->read<uintptr_t>(lunxian.Arrayaddr + 8 * i);

if (lunxian.Oneself == lunxian.Objaddr || lunxian.Objaddr <= 0x10000000 || lunxian.Objaddr % 4 != 0 || lunxian.Objaddr >= 0x10000000000)
continue;

uintptr_t object = driver->read<uintptr_t>(lunxian.Objaddr + 0x1b0);
if (object <= 0xffff || object == 0 || object <= 0x10000000 || object % 4 != 0 || object >= 0x10000000000)
continue;


if (driver->read<float>(lunxian.Objaddr + 0x29c8) != 479.5) {
GetClassName(wz.Name, lunxian.Gname, driver->read<int>(lunxian.Objaddr + 0x18));
driver->read(object + 0x1c0, &wz.Pos, 12);
GetDistance(wz.Pos, lunxian.MyPos, &wz.Distance);
WorldToScreen(&wz.ScreenPos, &wz.camera, &wz.w, wz.Pos);
} else {

// 倒地不绘制
// if (DrawIo[32] && lunxian.Health <= 0)
// continue;

// 人机不绘制
/*
if (DrawIo[17] && lunxian.IsBot == 1) 
continue;*/






// 死亡不绘制
int State = driver->read<int>(lunxian.Objaddr + 0xfa0);
        	if (State == 262144 || State == 262152)
continue;

// 自身队伍不绘制
lunxian.TeamID = driver->read<int>(lunxian.Objaddr + 0x928);
if (lunxian.TeamID == lunxian.MyTeam || lunxian.TeamID < 1)
continue;

// 血量百分比大于百分之100不绘制
lunxian.Health = (driver->read<float>(lunxian.Objaddr + 0xDB0) / driver->read<float>(lunxian.Objaddr + 0xDB4)) * 100;
if (lunxian.Health > 100)
continue;


driver->read(object + 0x1c0, &lunxian.Pos, 12); //读取坐标
// if(lunxian.Pos.x>0)
// cout<<lunxian.Pos.x<<endl;
GetDistance(lunxian.Pos, lunxian.MyPos, &lunxian.Distance); //用坐标计算出距离
WorldToScreen(&lunxian.ScreenPos, &lunxian.camera, &lunxian.w, lunxian.Pos); 

// 人机判断
long int 人机 = driver->read<int>(lunxian.Objaddr + 0x9d9);
   if (人机 == 16842753) {
       lunxian.IsBot = 1;
   }else {
       lunxian.IsBot = 0;
   }
// lunxian.IsBot = driver->read<int>(lunxian.Objaddr + 0x9e9);
/*
lunxian.IsBot = driver->read<int>(lunxian.Objaddr + 0x9d9);
   if (lunxian.IsBot == 16842753) {
       lunxian.IsBot = 1;
   }else {
       lunxian.IsBot = 0;
   }

*/
// (driver->read<int>(lunxian.Objaddr + 0x900) == 0);
// 统计人数
if (lunxian.IsBot) lunxian.BotCount++; else lunxian.PlayerCount++;

//人机不绘制
if(DrawIo[17])
{
  // 是否为人机
if (lunxian.IsBot == 1)
{
 continue;
}
}
// 超出屏幕不绘制
if (lunxian.w < 0 || lunxian.w > screen_x)
continue;


// if (driver->read<uintptr_t>(lunxian.Objaddr + 0x1c0)) {
// driver->read(driver->read<uintptr_t>(lunxian.Objaddr + 0x1c0) + 0x1330, &lunxian.Predict, sizeof(lunxian.Predict)); // 载具向量
// } else {
driver->read(driver->read<uintptr_t>(lunxian.Objaddr + 0x1b0) + 0x260, &lunxian.Predict, sizeof(lunxian.Predict)); // 敌人向量
// }

// 头甲包
long int rw = driver->read<uintptr_t>(driver->read<uintptr_t>(driver->read<uintptr_t>(lunxian.Objaddr + 0x348) + 0x30) + 0x388);
lunxian.drb = driver->read<int>(rw + 0x1C4);
lunxian.drt = driver->read<int>(rw + 0x1FC);
lunxian.drj = driver->read<int>(rw + 0x234);
 
// 动作，手持，当前子弹，最大子弹
lunxian.敌方动作 = driver->read<uintptr_t>(lunxian.Objaddr + 0xfa0);
lunxian.weapon = driver->read<uintptr_t>(driver->read<uintptr_t>(driver->read<uintptr_t>(driver->read<uintptr_t>(lunxian.Objaddr + 0x2488) + 0x558) + 0x840) + 0x178);//当前武器指针 自身手持
lunxian.dqzd = driver->read<int>(driver->read<uintptr_t>(driver->read<uintptr_t>(lunxian.Objaddr + 0x2488)+ 0x558)+0xF08); //子弹数量
lunxian.zdmax = driver->read<int>(driver->read<uintptr_t>(driver->read<uintptr_t>(lunxian.Objaddr + 0x2488)+ 0x558)+0xE88);//最大子弹数
// 名字   
getUTF8(lunxian.PlayerName, driver->read<uintptr_t>(lunxian.Objaddr + 0x8f0));

// 骨骼
lunxian.Mesh = driver->read<uintptr_t>(lunxian.Objaddr + 0x498);
lunxian.Human = lunxian.Mesh + 0x1B0;
lunxian.Bone = driver->read<uintptr_t>(lunxian.Mesh + 0x878)+0x30;


FTransform meshtrans = getBone(lunxian.Human);
FMatrix c2wMatrix = TransformToMatrix(meshtrans);

float MaxHealth = driver->read<float>(lunxian.Objaddr + 0xDB4);
/* 头部 */
FTransform headtrans;
if(MaxHealth<=150)
headtrans = getBone(lunxian.Bone + 5 * 48);
else
headtrans = getBone(lunxian.Bone + 5 * 48);
FMatrix boneMatrix = TransformToMatrix(headtrans);
lunxian.Head.Pos = MarixToVector(MatrixMulti(boneMatrix, c2wMatrix));
lunxian.Head.Pos.z += 7; /* 脖子长度 */
lunxian.Head.ScreenPos = WorldToScreen(lunxian.Head.Pos, lunxian.matrix, lunxian.camera);

/* 胸部 */
FTransform chesttrans;
if(MaxHealth<=150)
chesttrans = getBone(lunxian.Bone + 4 * 48);
else
chesttrans = getBone(lunxian.Bone + 4 * 48);
FMatrix boneMatrix1 = TransformToMatrix(chesttrans);
lunxian.Chest.Pos = MarixToVector(MatrixMulti(boneMatrix1, c2wMatrix));
lunxian.Chest.ScreenPos = WorldToScreen(lunxian.Chest.Pos, lunxian.matrix, lunxian.camera);

/* 盆骨 */
FTransform Pelvistrans;
if(MaxHealth<=150)
 Pelvistrans= getBone(lunxian.Bone + 0 * 48);
 else
 Pelvistrans= getBone(lunxian.Bone + 0 * 48);
FMatrix boneMatrix2 = TransformToMatrix(Pelvistrans);
lunxian.Pelvis.Pos = MarixToVector(MatrixMulti(boneMatrix2, c2wMatrix));
lunxian.Pelvis.ScreenPos = WorldToScreen(lunxian.Pelvis.Pos, lunxian.matrix, lunxian.camera);

/* 左肩膀 */
FTransform lshtrans;
if(MaxHealth<=150)
lshtrans = getBone(lunxian.Bone + 11 * 48);
else 
lshtrans = getBone(lunxian.Bone + 13 * 48);
FMatrix boneMatrix3 = TransformToMatrix(lshtrans);
lunxian.Left_Shoulder.Pos = MarixToVector(MatrixMulti(boneMatrix3, c2wMatrix));
lunxian.Left_Shoulder.ScreenPos = WorldToScreen(lunxian.Left_Shoulder.Pos, lunxian.matrix, lunxian.camera);

/* 右肩膀 */
FTransform rshtrans;
if(MaxHealth<=150)
rshtrans = getBone(lunxian.Bone + 32 * 48);
else
rshtrans = getBone(lunxian.Bone + 34 * 48);
FMatrix boneMatrix4 = TransformToMatrix(rshtrans);
lunxian.Right_Shoulder.Pos = MarixToVector(MatrixMulti(boneMatrix4, c2wMatrix));
lunxian.Right_Shoulder.ScreenPos = WorldToScreen(lunxian.Right_Shoulder.Pos, lunxian.matrix, lunxian.camera);

/* 左手肘 */
FTransform lelbtrans;
if(MaxHealth<=150)
lelbtrans = getBone(lunxian.Bone + 12 * 48);
else
lelbtrans = getBone(lunxian.Bone + 14 * 48);
FMatrix boneMatrix5 = TransformToMatrix(lelbtrans);
lunxian.Left_Elbow.Pos = MarixToVector(MatrixMulti(boneMatrix5, c2wMatrix));
lunxian.Left_Elbow.ScreenPos = WorldToScreen(lunxian.Left_Elbow.Pos, lunxian.matrix, lunxian.camera);

/* 右手肘 */
FTransform relbtrans;
if(MaxHealth<=150)
 relbtrans = getBone(lunxian.Bone + 33 * 48);
else
 relbtrans = getBone(lunxian.Bone + 35 * 48);
FMatrix boneMatrix6 = TransformToMatrix(relbtrans);
lunxian.Right_Elbow.Pos = MarixToVector(MatrixMulti(boneMatrix6, c2wMatrix));
lunxian.Right_Elbow.ScreenPos = WorldToScreen(lunxian.Right_Elbow.Pos, lunxian.matrix, lunxian.camera);

/* 左手腕 */
FTransform lwtrans;
if(MaxHealth<=150)
 lwtrans = getBone(lunxian.Bone + 63 * 48);
else
 lwtrans = getBone(lunxian.Bone + 16 * 48);
FMatrix boneMatrix7 = TransformToMatrix(lwtrans);
lunxian.Left_Wrist.Pos = MarixToVector(MatrixMulti(boneMatrix7, c2wMatrix));
lunxian.Left_Wrist.ScreenPos = WorldToScreen(lunxian.Left_Wrist.Pos, lunxian.matrix, lunxian.camera);

/* 右手腕 */
FTransform rwtrans;
if(MaxHealth<=150)
 rwtrans = getBone(lunxian.Bone + 62 * 48);
else
 rwtrans = getBone(lunxian.Bone + 37 * 48);
FMatrix boneMatrix8 = TransformToMatrix(rwtrans);
lunxian.Right_Wrist.Pos = MarixToVector(MatrixMulti(boneMatrix8, c2wMatrix));
lunxian.Right_Wrist.ScreenPos = WorldToScreen(lunxian.Right_Wrist.Pos, lunxian.matrix, lunxian.camera);

/* 左大腿 */
FTransform Llshtrans;
if(MaxHealth<=150)
 Llshtrans = getBone(lunxian.Bone + 52 * 48);
else
 Llshtrans = getBone(lunxian.Bone + 54 * 48);
FMatrix boneMatrix9 = TransformToMatrix(Llshtrans);
lunxian.Left_Thigh.Pos = MarixToVector(MatrixMulti(boneMatrix9, c2wMatrix));
lunxian.Left_Thigh.ScreenPos = WorldToScreen(lunxian.Left_Thigh.Pos, lunxian.matrix, lunxian.camera);

/* 右大腿 */
FTransform Lrshtrans;
if(MaxHealth<=150)
 Lrshtrans = getBone(lunxian.Bone + 56 * 48);
else
 Lrshtrans = getBone(lunxian.Bone + 58 * 48);
FMatrix boneMatrix10 = TransformToMatrix(Lrshtrans);
lunxian.Right_Thigh.Pos = MarixToVector(MatrixMulti(boneMatrix10, c2wMatrix));
lunxian.Right_Thigh.ScreenPos = WorldToScreen(lunxian.Right_Thigh.Pos, lunxian.matrix, lunxian.camera);

/* 左膝盖 */
FTransform Llelbtrans;
if(MaxHealth<=150)
 Llelbtrans = getBone(lunxian.Bone + 53 * 48);
else
 Llelbtrans = getBone(lunxian.Bone + 55 * 48);
FMatrix boneMatrix11 = TransformToMatrix(Llelbtrans);
lunxian.Left_Knee.Pos = MarixToVector(MatrixMulti(boneMatrix11, c2wMatrix));
lunxian.Left_Knee.ScreenPos = WorldToScreen(lunxian.Left_Knee.Pos, lunxian.matrix, lunxian.camera);

/* 右膝盖 */
FTransform Lrelbtrans;
if(MaxHealth<=150)
 Lrelbtrans = getBone(lunxian.Bone + 57 * 48);
else
 Lrelbtrans = getBone(lunxian.Bone + 59 * 48);
FMatrix boneMatrix12 = TransformToMatrix(Lrelbtrans);
lunxian.Right_Knee.Pos = MarixToVector(MatrixMulti(boneMatrix12, c2wMatrix));
lunxian.Right_Knee.ScreenPos = WorldToScreen(lunxian.Right_Knee.Pos, lunxian.matrix, lunxian.camera);

/* 左脚腕 */
FTransform Llwtrans;
if(MaxHealth<=150)
 Llwtrans = getBone(lunxian.Bone + 54 * 48);
else
 Llwtrans = getBone(lunxian.Bone + 56 * 48);
FMatrix boneMatrix13 = TransformToMatrix(Llwtrans);
lunxian.Left_Ankle.Pos = MarixToVector(MatrixMulti(boneMatrix13, c2wMatrix));
lunxian.Left_Ankle.ScreenPos = WorldToScreen(lunxian.Left_Ankle.Pos, lunxian.matrix, lunxian.camera);

/* 右脚腕 */
FTransform Lrwtrans;
if(MaxHealth<=150)
 Lrwtrans = getBone(lunxian.Bone + 58* 48);
else
 Lrwtrans = getBone(lunxian.Bone + 60 * 48);
FMatrix boneMatrix14 = TransformToMatrix(Lrwtrans);
lunxian.Right_Ankle.Pos = MarixToVector(MatrixMulti(boneMatrix14, c2wMatrix));
lunxian.Right_Ankle.ScreenPos = WorldToScreen(lunxian.Right_Ankle.Pos, lunxian.matrix, lunxian.camera);
		








float 距离限制;
if (lunxian.IsAiming == 1 || lunxian.IsAiming == 257)
距离限制 = NumIo[32];
else
距离限制 = NumIo[31];


if (DrawIo[20] && ((DrawIo[31] && !lunxian.IsBot) || !DrawIo[31]) && ((DrawIo[32] && lunxian.Health > 0) || !DrawIo[32]) && lunxian.Distance <= 距离限制) {
strcpy(Aim[AimCount].Name, lunxian.PlayerName);
Aim[AimCount].WodDistance = lunxian.Distance;
Aim[AimCount].AimMovement = lunxian.Predict;
if (NumIo[8] == 1.0){
Aim[AimCount].ObjAim = lunxian.Head.Pos;
Aim[AimCount].ScreenDistance = sqrt(pow(screen_x / 2 - lunxian.Head.ScreenPos.x, 2) + pow(screen_y / 2 - lunxian.Head.ScreenPos.y, 2));
} else if (NumIo[8] == 2.0){
Aim[AimCount].ObjAim = lunxian.Chest.Pos;
Aim[AimCount].ScreenDistance = sqrt(pow(screen_x / 2 - lunxian.Chest.ScreenPos.x, 2) + pow(screen_y / 2 - lunxian.Chest.ScreenPos.y, 2));
} else if (NumIo[8] == 3.0){
Aim[AimCount].ObjAim = lunxian.Pelvis.Pos; 
Aim[AimCount].ScreenDistance = sqrt(pow(screen_x / 2 - lunxian.Pelvis.ScreenPos.x, 2) + pow(screen_y / 2 - lunxian.Pelvis.ScreenPos.y, 2));
} else {
Aim[AimCount].ObjAim = lunxian.Head.Pos;
Aim[AimCount].ScreenDistance = sqrt(pow(screen_x / 2 - lunxian.Head.ScreenPos.x, 2) + pow(screen_y / 2 - lunxian.Head.ScreenPos.y, 2));
}  
AimCount++;
}

float top, right, left, bottom, top1; 


// 背敌
	if (DrawIo[8]) {//敌背
			
			
			if(draw_style[2]==0){
                std::string ssd;
                

ssd += "  队伍";
ssd += to_string((int)lunxian.TeamID);
                ssd += "  \n  [";
ssd += std::to_string((int) lunxian.Distance); 
ssd += "米]";

                auto textSize = ImGui::CalcTextSize(ssd.c_str(), 0, 28);
				dx = 120.f/255.f;
                if (lunxian.Head.ScreenPos.x + lunxian.w < 0) {
                    Draw->AddCircleFilled({40, lunxian.Head.ScreenPos.y}, 50, ImColor(arr[lunxian.TeamID%length]));    
                    Draw->AddText(NULL, 28, {40 - (textSize.x / 2), lunxian.Head.ScreenPos.y - (textSize.y / 2)}, ImColor(255, 255, 255), ssd.c_str());                                      
                } else if (lunxian.w > 0 && lunxian.Head.ScreenPos.x > screen_x) {
                    Draw->AddCircleFilled({screen_x - 40, lunxian.Head.ScreenPos.y}, 50, ImColor(arr[lunxian.TeamID%length]));                       
                    Draw->AddText(NULL, 28, {screen_x - 40 - (textSize.x / 2), lunxian.Head.ScreenPos.y - (textSize.y / 2)}, ImColor(255, 255, 255), ssd.c_str());                                      
                } else if (lunxian.w > 0 && lunxian.Head.ScreenPos.y + lunxian.w < 0) {               
                    Draw->AddCircleFilled({lunxian.Head.ScreenPos.x, 40}, 50, ImColor(arr[lunxian.TeamID%length]));     
                    Draw->AddText(NULL, 28, {lunxian.Head.ScreenPos.x - (textSize.x / 2), 40 - (textSize.y / 2)}, ImColor(255, 255, 255), ssd.c_str());                                      
                } else if (lunxian.w < 0) {
                    Draw->AddCircleFilled({screen_x - lunxian.Head.ScreenPos.x, screen_y - 40}, 50, ImColor(arr[lunxian.TeamID%length]));   
                    Draw->AddText(NULL, 28, {screen_x - lunxian.Head.ScreenPos.x - (textSize.x / 2), screen_y - 40 - (textSize.y / 2)}, ImColor(255, 255, 255), ssd.c_str());                                      
                }
                }
		
              if(draw_style[2]==1){  
				dx = 120.f/255.f;
				float cameras = lunxian.matrix[3] * lunxian.Pos.x + lunxian.matrix[7] * lunxian.Pos.y + lunxian.matrix[11] * lunxian.Pos.z + lunxian.matrix[15]; 
				if (!lunxian.IsBot) {				
					OffScreen(lunxian.ScreenPos, cameras, ImColor(arr[lunxian.TeamID%length]), NumIo[3] + 20 + lunxian.Distance * 0.3);
				} else {
					OffScreen(lunxian.ScreenPos, cameras, ImColor(255, 255, 255, 255), NumIo[3] + 20 + lunxian.Distance * 0.3);
				}
				
				}
            }



left  = lunxian.Head.ScreenPos.x - lunxian.w * 0.6;
right = lunxian.Head.ScreenPos.x + lunxian.w * 0.6;

if (!lunxian.Head.Pos.x) {
top1 = lunxian.Pelvis.ScreenPos.y - lunxian.Chest.ScreenPos.y;
} else {
top1 = lunxian.Pelvis.ScreenPos.y - lunxian.Head.ScreenPos.y;
}

top  = lunxian.Pelvis.ScreenPos.y - top1 - lunxian.w / 5;

if (lunxian.Left_Ankle.ScreenPos.y < lunxian.Right_Ankle.ScreenPos.y) {
bottom = lunxian.Right_Ankle.ScreenPos.y + lunxian.w / 10;
} else {
bottom = lunxian.Left_Ankle.ScreenPos.y  + lunxian.w / 10;
}

//方框
if (DrawIo[1]) {
    if (lunxian.IsBot) { 
        // 人机方框（默认白色）
        Draw->AddRect({left, top}, {right, bottom}, 绘制颜色[2], 0, 0, 绘制粗细[2]); 
        Draw->AddRectFilled({left, top}, {right, bottom}, 绘制颜色[4]); 
    } else {  
        // 初始化颜色和边框
        ImColor fillColor = ImColor(255, 255, 255, 50);  // 默认半透明白色
        ImColor borderColor = 绘制颜色[1];               // 默认边框颜色
        float borderThickness = 绘制粗细[1];            // 默认边框粗细

        // --- 优先级1: 特殊状态（倒地/开车） ---
        if (lunxian.敌方动作 == 524288 || lunxian.敌方动作 == 131072 || lunxian.敌方动作 == 524303) {
            // 倒地状态 - 黑色背景
            fillColor = ImColor(0, 0, 0, 80);
            borderColor = ImColor(0, 0, 0, 255);
            borderThickness = 2.0f;
        } else if (lunxian.敌方动作 == 12583952 || lunxian.敌方动作 == 12582928) {
            // 开车状态 - 黄色背景
            fillColor = ImColor(255, 255, 0, 60);
            borderColor = ImColor(255, 255, 0, 200);
            borderThickness = 2.0f;
        } 
        // --- 优先级2: 投掷动作（手雷倒计时） ---
        else if (lunxian.敌方动作 == 65552 or lunxian.敌方动作 == 69648 or lunxian.敌方动作 == 69664 or lunxian.敌方动作 == 65600 or lunxian.敌方动作 == 65681 or lunxian.敌方动作 == 65569 or lunxian.敌方动作 == 65601 or lunxian.敌方动作 == 65553 or lunxian.敌方动作 == 69649 or lunxian.敌方动作 ==17417 or lunxian.敌方动作 == 16401) {
               Draw->AddRectFilled({left, top}, {right, bottom}, ImColor(255,0,0,50));//背景颜色     填充色
Draw->AddRect({left, top}, {right, bottom}, ImColor(255, 0, 0, 255)); // 红色边框，不填充颜色
// 绘制7秒倒数文本
    static float countdown = 7.0f;
    static std::chrono::steady_clock::time_point lastTime = std::chrono::steady_clock::now();
    auto currentTime = std::chrono::steady_clock::now();
    std::chrono::duration<float> elapsedSeconds = currentTime - lastTime;

    if (elapsedSeconds.count() >= 1.0f) {
        countdown -= elapsedSeconds.count();
        lastTime = currentTime;
    }
        if (countdown > 0) {
        char buffer[32];
        sprintf(buffer, "%.1f", countdown);
        Draw->AddText({left + 10, top + 10}, ImColor(255, 255, 255, 255), buffer); // 白色文本
    } else {
        countdown = 7.0f; // 重置倒计时
    }
    }
        // --- 优先级3: 危险武器/手雷判断 ---
        else if (lunxian.scwq == 602003 || lunxian.scwq == 602004) { 
            // 手持手雷/燃烧瓶 - 亮红色
            fillColor = ImColor(255, 50, 50, 150);
            borderColor = ImColor(255, 0, 0, 255);
            borderThickness = 3.0f;
        } else if (
            (lunxian.scwq >= 103000 && lunxian.scwq < 104000) ||  // 狙击枪
            (lunxian.scwq >= 104000 && lunxian.scwq < 105000)     // 霰弹枪
        ) { 
            // 狙击枪/霰弹枪 - 浅红色
            fillColor = ImColor(255, 100, 100, 150);
            borderColor = ImColor(255, 100, 100, 200);
            borderThickness = 2.0f;
        }
        // --- 优先级4: 武器等级（破损/改进/精致等） ---
        else {
            int weaponID = lunxian.scwq;
            int suffix = weaponID % 10; // 取最后一位判断等级

            switch (suffix) {
                case 1: // 破损
                    fillColor = ImColor(128, 0, 0, 150);    // 暗红色
                    borderColor = ImColor(200, 0, 0, 200);
                    break;
                case 2: // 修复
                    fillColor = ImColor(255, 165, 0, 150);  // 橙色
                    borderColor = ImColor(255, 140, 0, 200);
                    break;
                case 3: // 完好
                    fillColor = ImColor(255, 255, 0, 150);  // 黄色
                    borderColor = ImColor(255, 215, 0, 200);
                    break;
                case 4: // 改进
                    fillColor = ImColor(0, 128, 0, 150);    // 绿色
                    borderColor = ImColor(50, 205, 50, 200);
                    break;
                case 5: // 精致
                    fillColor = ImColor(0, 0, 255, 150);    // 蓝色
                    borderColor = ImColor(30, 144, 255, 200);
                    break;
                case 6: // 卓越
                    fillColor = ImColor(128, 0, 128, 150);  // 紫色
                    borderColor = ImColor(147, 112, 219, 200);
                    break;
                default: // 无等级或未知
                    fillColor = ImColor(255, 255, 255, 50); 
                    borderColor = 绘制颜色[1];
                    break;
            }
        }

        // 绘制方框（填充+边框）
        Draw->AddRectFilled({left, top}, {right, bottom}, fillColor);
        Draw->AddRect({left, top}, {right, bottom}, borderColor, 0, 0, borderThickness);
    }
}



// 射线
if (DrawIo[2]) {
float 射线_y;
if (lunxian.IsBot) {
if (draw_style[0] == 0 || draw_style[0] == 1) 射线_y = 73; else if (draw_style[0] == 2) 射线_y = screen_y*0.135f;
Draw->AddLine({screen_x / 2 , 射线_y}, {lunxian.Head.ScreenPos.x, lunxian.Head.ScreenPos.y}, 绘制颜色[6], 绘制粗细[4]);  
} else {
Draw->AddLine({screen_x / 2 , 射线_y}, {lunxian.Head.ScreenPos.x, lunxian.Head.ScreenPos.y}, 绘制颜色[5], 绘制粗细[3]);  
}
}
// 距离
if (DrawIo[5]) {
string 距离 = to_string((int) lunxian.Distance);
距离 += " M";
auto textSize_距离 = ImGui::GetFont()->CalcTextSizeA((25), FLT_MAX, -1, 距离.c_str(), NULL, NULL);
DrawTf.绘制字体描边(25, lunxian.Pelvis.ScreenPos.x - textSize_距离.x/2, bottom + 15, ImVec4{1.0f, 1.0f, 1.0f, 1.0f},  距离.c_str());
if(lunxian.Distance < 100){
string str = "近点来人了";
        auto textSize = ImGui::CalcTextSize(str.c_str(), 0, 25);            
        ImGui::GetForegroundDrawList()->AddText(NULL,48,{screen_x / 2 - 99,200}, ImColor(255,0,0), str.c_str());
}
}
ImColor 白色 = ImColor(255, 255, 255);
ImColor 红色 = ImColor(255,0,0, 255);
ImColor 绿色 = ImColor(0,250,250, 0);
// 骨骼
if (DrawIo[3]) {
Draw->AddCircle({lunxian.Head.ScreenPos.x, lunxian.Head.ScreenPos.y}, lunxian.w / 6, 绘制颜色[7], 100);
DrawBone({lunxian.Head.ScreenPos.x, lunxian.Head.ScreenPos.y}, {lunxian.Chest.ScreenPos.x, lunxian.Chest.ScreenPos.y});
DrawBone({lunxian.Chest.ScreenPos.x, lunxian.Chest.ScreenPos.y}, {lunxian.Pelvis.ScreenPos.x, lunxian.Pelvis.ScreenPos.y});
DrawBone({lunxian.Chest.ScreenPos.x, lunxian.Chest.ScreenPos.y}, {lunxian.Left_Shoulder.ScreenPos.x, lunxian.Left_Shoulder.ScreenPos.y});
DrawBone({lunxian.Chest.ScreenPos.x, lunxian.Chest.ScreenPos.y}, {lunxian.Right_Shoulder.ScreenPos.x, lunxian.Right_Shoulder.ScreenPos.y});
DrawBone({lunxian.Left_Shoulder.ScreenPos.x, lunxian.Left_Shoulder.ScreenPos.y}, {lunxian.Left_Elbow.ScreenPos.x, lunxian.Left_Elbow.ScreenPos.y});
DrawBone({lunxian.Right_Shoulder.ScreenPos.x, lunxian.Right_Shoulder.ScreenPos.y},{lunxian.Right_Elbow.ScreenPos.x, lunxian.Right_Elbow.ScreenPos.y});
DrawBone({lunxian.Left_Elbow.ScreenPos.x, lunxian.Left_Elbow.ScreenPos.y}, {lunxian.Left_Wrist.ScreenPos.x, lunxian.Left_Wrist.ScreenPos.y});
DrawBone({lunxian.Right_Elbow.ScreenPos.x, lunxian.Right_Elbow.ScreenPos.y}, {lunxian.Right_Wrist.ScreenPos.x, lunxian.Right_Wrist.ScreenPos.y});
DrawBone({lunxian.Pelvis.ScreenPos.x, lunxian.Pelvis.ScreenPos.y}, {lunxian.Left_Thigh.ScreenPos.x, lunxian.Left_Thigh.ScreenPos.y});
DrawBone({lunxian.Pelvis.ScreenPos.x, lunxian.Pelvis.ScreenPos.y}, {lunxian.Right_Thigh.ScreenPos.x, lunxian.Right_Thigh.ScreenPos.y});
DrawBone({lunxian.Left_Thigh.ScreenPos.x, lunxian.Left_Thigh.ScreenPos.y}, {lunxian.Left_Knee.ScreenPos.x, lunxian.Left_Knee.ScreenPos.y});
DrawBone({lunxian.Right_Thigh.ScreenPos.x, lunxian.Right_Thigh.ScreenPos.y}, {lunxian.Right_Knee.ScreenPos.x, lunxian.Right_Knee.ScreenPos.y});
DrawBone({lunxian.Left_Knee.ScreenPos.x, lunxian.Left_Knee.ScreenPos.y}, {lunxian.Left_Ankle.ScreenPos.x, lunxian.Left_Ankle.ScreenPos.y});
DrawBone({lunxian.Right_Knee.ScreenPos.x, lunxian.Right_Knee.ScreenPos.y}, {lunxian.Right_Ankle.ScreenPos.x, lunxian.Right_Ankle.ScreenPos.y});
if(lunxian.Distance > 200){
绘制颜色[7] = 白色;
} else {
绘制颜色[7] = 红色;
}
}

if(DrawIo[67]){//漏手模式专用
Draw->AddCircleFilled({lunxian.Head.ScreenPos.x, lunxian.Head.ScreenPos.y}, lunxian.w / 15,白色, 100);
}



if(DrawIo[19]){
//绘制头部骨骼节点
Draw->AddCircleFilled({lunxian.Head.ScreenPos.x, lunxian.Head.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制左肩骨骼点
Draw->AddCircleFilled({lunxian.Left_Shoulder.ScreenPos.x, lunxian.Left_Shoulder.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制右肩骨骼点
Draw->AddCircleFilled({lunxian.Right_Shoulder.ScreenPos.x, lunxian.Right_Shoulder.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制左肘骨骼点
Draw->AddCircleFilled({lunxian.Left_Elbow.ScreenPos.x, lunxian.Left_Elbow.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制右肘骨骼点
Draw->AddCircleFilled({lunxian.Right_Elbow.ScreenPos.x, lunxian.Right_Elbow.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制左腕骨骼点
Draw->AddCircleFilled({lunxian.Left_Wrist.ScreenPos.x, lunxian.Left_Wrist.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制右腕骨骼点
Draw->AddCircleFilled({lunxian.Right_Wrist.ScreenPos.x, lunxian.Right_Wrist.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制左大腿骨骼点
Draw->AddCircleFilled({lunxian.Left_Thigh.ScreenPos.x, lunxian.Left_Thigh.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制右大腿骨骼点
Draw->AddCircleFilled({lunxian.Right_Thigh.ScreenPos.x, lunxian.Right_Thigh.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制左膝盖骨骼点
Draw->AddCircleFilled({lunxian.Left_Knee.ScreenPos.x, lunxian.Left_Knee.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制右膝盖骨骼点
Draw->AddCircleFilled({lunxian.Right_Knee.ScreenPos.x, lunxian.Right_Knee.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制左脚踝骨骼点
Draw->AddCircleFilled({lunxian.Left_Ankle.ScreenPos.x, lunxian.Left_Ankle.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
// 绘制右脚踝骨骼点
Draw->AddCircleFilled({lunxian.Right_Ankle.ScreenPos.x, lunxian.Right_Ankle.ScreenPos.y}, lunxian.w / 15, 绘制颜色[7], 100);
}


// 血量&名字
if (DrawIo[6]) {
if (!lunxian.IsBot) {
DrawHealth({lunxian.Head.ScreenPos.x, top }, lunxian.w * 2, lunxian.Health, lunxian.TeamID, lunxian.PlayerName);
} else {
DrawHealth({lunxian.Head.ScreenPos.x, top }, lunxian.w * 2, lunxian.Health, lunxian.TeamID, "人机");
}
}



//手持武器
// int  武器id;// 绘制手持图片请取消注释此行  4/7    和平精英同理也要删对应这几行
// 武器id = GetWeapon(lunxian.scwq);// 绘制手持图片请取消注释此行 5/7 和平精英同理也要删对应这几行

if (DrawIo[10])
{
  string s;
  s += GetHol(lunxian.scwq);
  s += " ";
  s += to_string((int)lunxian.dqzd);
  s += "/";
  s += to_string((int)lunxian.zdmax);
  auto textSize = ImGui::GetFont()->CalcTextSizeA(25, FLT_MAX, -1, s.c_str(), NULL, NULL); 
  ImGui::GetForegroundDrawList()->AddText(NULL, 25.f, { lunxian.Head.ScreenPos.x - (textSize.x / 2), top - 45 - (textSize.y / 2) }, ImColor(255,255,255,255), s.c_str());
  PlayerId = lunxian.scwq;

// float png_y = (DrawIo[10] == true) ? 45 : 0; // 绘制手持图片请取消注释此行  6/7 
// ImGui::GetForegroundDrawList()->AddImage(weapon[武器id/10], {lunxian.Head.ScreenPos.x - 60, top - 80 - png_y}, {lunxian.Head.ScreenPos.x + 60, top - 40 - png_y}); // 绘制手持图片请取消注释此行 7/7
}



} //人物绘制结束


float aa;
float bb;
int Health;
int Distance;

// if (draw_style[66] == 0) {
if (DrawIo[7]) {
    float radius = 200.0f;
    ImVec2 center = {NumIo[1], NumIo[2]};
    ImColor color(0, 255, 255, 255); // 青色的RGB值为(0, 255, 255)
    Draw->AddCircle(center, radius, color, 100, 2.0f); // 添加圆形
    
    // 添加静态十字线
    ImVec2 crosshairStart(center.x, center.y - radius); // 十字架上方的点
    ImVec2 crosshairEnd(center.x, center.y + radius); // 十字架下方的点
    Draw->AddLine(crosshairStart, crosshairEnd, color, 2.0f); // 添加十字架的竖线
    crosshairStart = ImVec2(center.x - radius, center.y); // 十字架左侧的点
    crosshairEnd = ImVec2(center.x + radius, center.y); // 十字架右侧的点
    Draw->AddLine(crosshairStart, crosshairEnd, color, 2.0f); // 添加十字架的横线

    // 添加静态小圆圈
    float smallRadius = 100.0f;
    ImVec2 smallCenter = center;
    Draw->AddCircle(smallCenter, smallRadius, color, 100, 2.0f);
}

/*if(DrawIo[16384])
{  
    float fps = ImGui::GetIO().Framerate;
    std::string sFPS = "帧率: " + std::to_string(fps);
    Draw->AddText(NULL, 25, {150, 25}, ImColor(255, 0, 0), sFPS.c_str());       
    ImVec2 watermarkPos(150, 85);
}*/

for (int i = 0; i < lunxian.Count; i++)
{
    Distance = lunxian.Distance;
    Health = lunxian.Health;
    if (lunxian.Distance > NumIo[17])
        continue;
        
    Vec2 Radar = {(lunxian.MyPos.x - lunxian.Pos.x) / NumIo[16], (lunxian.MyPos.y - lunxian.Pos.y) / NumIo[16]};

    // 雷达坐标转换
    float middlex = Radar.y;
    Radar.y = -Radar.x;
    Radar.x = middlex;
    float sina = -Radar.y / sqrt(Radar.x * Radar.x + Radar.y * Radar.y);
    float cosa = -Radar.x / sqrt(Radar.x * Radar.x + Radar.y * Radar.y);
    float xiebian = sqrt(lunxian.matrix[7] * lunxian.matrix[7] + lunxian.matrix[3] * lunxian.matrix[3]);
    float sinb = lunxian.matrix[7] / xiebian;
    float cosb = lunxian.matrix[3] / xiebian;
    float dis = sqrt(Radar.x * Radar.x + Radar.y * Radar.y);

    float sinab = sina * cosb - sinb * cosa;
    float cosab = cosa * cosb + sina * sinb;
    aa = sinb;
    bb = cosb;

    Radar.x = dis * cosab;
    Radar.y = dis * sinab;

    if ((Radar.x) * (Radar.x) + (Radar.y) * (Radar.y) <= 40000) {
        if (lunxian.IsBot) {
            Draw->AddCircleFilled({NumIo[1] + Radar.x, NumIo[2] + Radar.y}, 3, ImColor(255, 255, 255));
        } else {
            dx = 150.f / 255.f;
            Draw->AddCircleFilled({NumIo[1] + Radar.x, NumIo[2] + Radar.y}, 15, ImColor(arr[lunxian.TeamID % length]));
            string sdt = to_string((int)lunxian.TeamID);
            auto textSize = ImGui::CalcTextSize(sdt.c_str(), 0, 25);
            Draw->AddText(NULL, 25, {NumIo[1] + Radar.x - textSize.x / 2, NumIo[2] + Radar.y - textSize.y * 0.45}, ImColor(255, 255, 255), sdt.c_str());
        }
    }
}

if (wz.w > 0){
if (wzhz[2]) {
    if(!(wz.w < 0 || wz.w > screen_x)){
        if (lunxian.Distance < 2000.0f) {
            std::string WzClassName = GetClssName(lunxian.Objaddr);
            //匹配物资名字
            std::string_view WzName_view = reader.getValue(WzClassName);
            //如果字符串WzName_view不为空
            if (!WzName_view.empty()) {
                //转换WzName_view为std::string
                std::string WzName(WzName_view.begin(), WzName_view.end());
                char WzName_Distance[64];
                std::string formatted = std::string("%s[") + std::to_string((int)wz.Distance) + "米]";
                sprintf(WzName_Distance, formatted.c_str(), WzName.c_str());
                Draw->AddText(NULL,23, ImVec2(wz.ScreenPos.x, wz.ScreenPos.y),ImColor(255,215,0), WzName_Distance);
            }
        }
    }
}
// string 狗子(const string& n) {
// if (alike(n, "Watcher_C") || alike(n, "Watcher_Child_C") || alike(n, "HungerH_C") || alike(n, "HungerB_C") || alike(n, "VenomVariant_C") || alike(n, "BurningVariant_C") || alike(n, "Library_C") || alike(n, "AIMob_PatrolDog_C"))
// return "狗子";
// return "";
// }

/*  if (DrawIo[71]&&niubi(wz.Name, &CasName)) { //牛逼东西
string name;
name += CasName;
if(wz.Distance<400){
name += "[";
name += to_string((int)wz.Distance);
name += "米]";
auto textSize = ImGui::CalcTextSize(name.c_str(),0, 30);
Draw->AddText(NULL, 20,{wz.ScreenPos.x-(textSize.x / 2), wz.ScreenPos.y}, ImColor(255,0,0,255), name.c_str());  
  }
  }

if (DrawIo[72]&&BOOS(wz.Name, &CasName)) { //地铁BOOS
string name;
name += CasName;
if(wz.Distance<400){
name += "[";
name += to_string((int)wz.Distance);
name += "米]";
auto textSize = ImGui::CalcTextSize(name.c_str(),0, 30);
Draw->AddText(NULL, 20,{wz.ScreenPos.x-(textSize.x / 2), wz.ScreenPos.y}, ImColor(255,255,0,255), name.c_str());  
  }
  }

if (DrawIo[73]&&kongtou(wz.Name, &CasName)) { //空投
string name;
name += CasName;
if(wz.Distance<400){
name += "[";
name += to_string((int)wz.Distance);
name += "米]";
auto textSize = ImGui::CalcTextSize(name.c_str(),0, 30);
Draw->AddText(NULL, 20,{wz.ScreenPos.x-(textSize.x / 2), wz.ScreenPos.y}, ImColor(255,255,0,255), name.c_str());  
  }
  }
// {
// string name;
// name += "[";
// name += to_string((int)wz.Distance);
// name += "米]";
// auto textSize = ImGui::CalcTextSize(name.c_str(),0, 20);
// Draw->AddText(NULL, 30,{wz.ScreenPos.x-(textSize.x / 2), wz.ScreenPos.y}, ImColor(0, 258, 0, 255), wz.Name);  
// }

*/

if (DrawIo[14]) {
string name;
string name1;
string name2;
name += "手榴弹[" + to_string((int)wz.Distance) + "米]\n";
name1 += "燃烧瓶[" + to_string((int)wz.Distance) + "米]\n";
name2 += "烟雾弹[" + to_string((int)wz.Distance) + "米]\n";
if (strstr(wz.Name, "ProjGrenade_BP_C") || strstr(wz.Name, "BP_Grenade_Shoulei_C")) {
Draw->AddText(NULL, 20, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 0, 0), name.c_str());
Draw->AddCircle({ wz.ScreenPos.x, wz.ScreenPos.y }, 45.0f, ImColor(255, 0, 0), 12);
} else if (strstr(wz.Name, "BP_Grenade_Burn_C") || strstr(wz.Name, "ProjBurn_BP_C")) {
Draw->AddText(NULL, 20, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(255, 255, 0), name1.c_str());
Draw->AddCircle({ wz.ScreenPos.x, wz.ScreenPos.y }, 45.0f, ImColor(255, 0, 0), 12);
} else if (strstr(wz.Name, "BP_Grenade_Smoke_C")) {
Draw->AddText(NULL, 25, { wz.ScreenPos.x - 25, wz.ScreenPos.y - 10 }, ImColor(0, 255, 0), name2.c_str());
Draw->AddCircle({ wz.ScreenPos.x, wz.ScreenPos.y }, 45.0f, ImColor(0, 255, 0), 12);
}


if (strstr(wz.Name, "BP_Grenade_Shoulei_C") || strstr(wz.Name, "BP_Grenade_Burn_C")) {
if (wz.Distance < 100) {
// 在屏幕中间绘制一个附近有手雷的文本
string guistr = "附近有投掷物";
Draw->AddText(NULL, 70, {screen_x/2 -160, screen_y  -900}, ImColor(255, 0, 0), guistr.c_str());
}
}
}
}

//基址功能 来自NRMM

		if (DrawIo[301]) {
				// 无后
				driver->WriteAddress<float>(lunxian.libUE4 + 0x576E570, 8.841167304288883E-21);		           
				 }
				 
		if (DrawIo[300]) {
				// 聚点
				driver->WriteAddress<float>(lunxian.libUE4 + 0x5769F10, 8.479635254434225E-21);			  
            }
            
		if (DrawIo[308]) {
				// 射速
				driver->WriteAddress<float>(lunxian.libUE4 + 0x60AC564, 9.53154080613745E-21);
				  
            }



} //总循环
MaxPlayerCount = AimCount;
lunxian.TotalUp = lunxian.PlayerCount + lunxian.BotCount;