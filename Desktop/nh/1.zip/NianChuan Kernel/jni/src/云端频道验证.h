
#include <iostream>
#include <chrono>
#include <thread>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_LENGTH 1024

char* getSubstring(char* str, const char* startTag, const char* endTag) {
    char* start = strstr(str, startTag);
    if (!start) return NULL;
    start += strlen(startTag);

    char* end = strstr(start, endTag);
    if (!end) return NULL;

    size_t len = end - start;
    char* result = (char*)malloc(len + 1);
    strncpy(result, start, len);
    result[len] = '\0';
    return result;
}

char** getPackageNames(int* numPackages) {
    static char* packageNames[] = {
        "org.telegram.messenger",
        "org.telegram.messenger.web",
        "tw.nekomimi.nekogram",
        "org.telegram.csc.messenger",
        "org.thunderdog.challegram",
        "nekox.messenger",
        "xyz.nextalone.nagram"
    };
    *numPackages = sizeof(packageNames) / sizeof(packageNames[0]);
    return packageNames;
}

int checkFileExistence(const char* basePath, const char* fileName) {
    char filePath[1024];
    snprintf(filePath, sizeof(filePath), "%s/%s", basePath, fileName);
    return access(filePath, F_OK) == 0 ? 1 : 0;
}

// 修改后的函数：未找到包名直接退出
void openTelegramChannel() {
    int num_packages;
    char** package_names = getPackageNames(&num_packages);
    char command[512];
    char url[] = "https://t.me/wwacgt";
    bool found_package = false;

    // 遍历包名检查是否安装
    for (int i = 0; i < num_packages; ++i) {
        snprintf(command, sizeof(command), "pm list packages | grep -q \"^package:%s$\"", package_names[i]);
        if (system(command) == 0) {
            found_package = true;
            break; // 只要找到一个包就跳出循环
        }
    }

    // 未找到任何Telegram包直接退出
    if (!found_package) {
        printf("\n\033[31;1m未检测到Telegram应用，程序退出。\n");
        exit(1);
    }

    // 尝试跳转频道
    for (int i = 0; i < num_packages; ++i) {
        snprintf(command, sizeof(command), "pm list packages | grep -q \"^package:%s$\"", package_names[i]);
        if (system(command) == 0) {
            snprintf(command, sizeof(command), "am start -a android.intent.action.VIEW -d \"%s\" -n \"%s/org.telegram.ui.LaunchActivity\" > /dev/null 2>&1", url, package_names[i]);
            if (system(command) == 0) {
                printf("\n\033[32;1m已成功跳转频道！请自觉加入！！！\n");
                return;
            } else {
                printf("\n\033[31;1m跳转失败，程序退出。\n");
                exit(1);
            }
        }
    }
}

int 获取频道验证开关() {
    char url[128];
    sprintf(url, "curl -s %s", "https://sharechain.qq.com/caad180d4584bccda6d3bbbe06f19b75");
    FILE* fp = popen(url, "r");
    if (!fp) return 0;

    char buf[MAX_LENGTH];
    while (fgets(buf, MAX_LENGTH, fp)) {
        char* version = strstr(buf, "[频道验证]");
        if (version) {
            pclose(fp);
            char* extracted = getSubstring(version, "[频道验证]", "[频道验证]");
            if (!extracted) return 0;
            int val = atoi(extracted);
            free(extracted);
            return val;
        }
    }
    pclose(fp);
    return 0;
}

int 云端频道验证() {
    const int 频道开关 = 1;
    int 频道验证开关 = 获取频道验证开关();

    if (频道验证开关 > 频道开关) {
        int numPackages;
        char** packageNames = getPackageNames(&numPackages);
        char* fileNames[] = {"cache/-6300933876587022061_99.jpg", "cache/-6264920992421889552_99.jpg"};
        int numFiles = sizeof(fileNames) / sizeof(fileNames[0]);

        for (int i = 0; i < numPackages; ++i) {
            char basePath[1024];
            snprintf(basePath, sizeof(basePath), "/storage/emulated/0/Android/data/%s", packageNames[i]);
            for (int j = 0; j < numFiles; ++j) {
                if (checkFileExistence(basePath, fileNames[j])) {
                    printf("\n\033[32;1m频道验证成功！欢迎使用内核\n");
                    return 0;
                }
            }
        }

        while (1) {
            printf("\n\033[31;1m频道验证失败！是否跳转频道？\n");
            printf("\033[31;1m请输入 是[Y] 否[N] [y/n]: \033[0m");

            char response[10];
            if (!fgets(response, sizeof(response), stdin)) {
                printf("\n\033[31;1m输入错误，程序退出。\n");
                exit(1);
            }

            response[strcspn(response, "\n")] = '\0';

            if (strcasecmp(response, "是") == 0 || strcasecmp(response, "y") == 0 || strcasecmp(response, "Y") == 0) {
                openTelegramChannel(); // 调用时会自动检测Telegram是否存在
                printf("\n\033[31;1m|||—>—>—>—>–>–>–>–>–>—>—>–>–>–>–>|||\n");
                return 0;
            } else if (strcasecmp(response, "否") == 0 || strcasecmp(response, "n") == 0 || strcasecmp(response, "N") == 0) {
                printf("\n\033[31;1m未选择跳转，程序退出。\n");
                exit(1);
            } else {
                printf("\n\033[31;1m输入无效，请重新输入。\n");
            }
        }
    }
    else {
        printf("\n\033[31;1m云端频道验证已关闭\n|||—>—>—>—>–>–>–>–>–>—>—>–>–>–>–>|||\n");
    }
    return 0;
}