//  内置驱动例子.h   —— 不退出版
#ifndef 内置驱动例子_H
#define 内置驱动例子_H

#include <iostream>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <sys/utsname.h>
#include <sys/stat.h>
#include <unistd.h>

using namespace std;
int NianChuan内核;

/* ---------- 工具 ---------- */
char *kernell()
{
    struct utsname unameData;
    if (uname(&unameData) == 0) return strdup(unameData.release);

    ifstream version_file("/proc/version");
    string line;
    if (getline(version_file, line)) {
        size_t ver_start = line.find("Linux version ") + 13;
        size_t ver_end   = line.find(' ', ver_start);
        string kernel_ver = line.substr(ver_start, ver_end - ver_start);
        size_t dot_pos = kernel_ver.find('.', kernel_ver.find('.') + 1);
        string major_ver = kernel_ver.substr(0, dot_pos);
        return strdup(major_ver.c_str());
    }
    printf("[-] 无法获取内核版本\n");
    return nullptr;
}

bool fileExists(const string &filename)
{
    ifstream f(filename);
    return f.good();
}

/* ---------- 刷入 / 判断 ---------- */
int Brush_in()
{
    const string koPath = "/sdcard/NianChuan内核/驱动.ko";
    if (!fileExists(koPath)) {
        printf("[!] 驱动文件不存在，跳过刷入: %s\n", koPath.c_str());
        return -1;          // 不退出，仅返回错误码
    }

    int ret = system("sh /sdcard/NianChuan内核/驱动.ko > /dev/null");
    system("rm -rf /sdcard/NianChuan内核/驱动.ko");

    if (ret != 0) {
        printf("[-] 刷入脚本执行失败，返回值=%d\n", ret);
        return -1;
    }
    printf("[+] 刷入脚本执行完成\n");
    return 0;
}

/* ---------- 各版本分支 ---------- */
int 驱动5点10()
{
    printf("检测到多个 5.10 内核，请手动把对应驱动重命名为“驱动.ko”后放到 /sdcard/NianChuan内核/\n");
    printf("1.驱动5.10\n2.驱动5.10b\n3.驱动5.10-Pixel\n请输入序号：");
    scanf("%d", &NianChuan内核);
    Brush_in();      // 不 exit
    return 0;
}

int install()
{
    char *kernel_version = kernell();
    if (!kernel_version) return -1;
    printf("内核版本: %s\n", kernel_version);

    /* 以下所有分支只给提示，不 exit */
    if (strncmp(kernel_version, "4.9.186", 7) == 0) {
        printf("[+] 请手动放入 4.9.186 驱动，文件名为“驱动.ko”\n");
        Brush_in(); return 1;
    }
    if (strncmp(kernel_version, "4.14.117", 8) == 0) {
        printf("[+] 请手动放入 4.14.117 驱动，文件名为“驱动.ko”\n");
        Brush_in(); return 1;
    }
    if (strncmp(kernel_version, "4.14.180", 8) == 0) {
        printf("[+] 请手动放入 4.14.180 驱动，文件名为“驱动.ko”\n");
        Brush_in(); return 1;
    }
    if (strncmp(kernel_version, "4.14.186", 8) == 0) {
        printf("检测到多个 4.14.186 驱动，请手动选择并命名为“驱动.ko”\n");
        printf("1.驱动4.14.186(1)\n2.驱动4.14.186(2)\n3.驱动4.14.186(3)\n请输入序号：");
        scanf("%d", &NianChuan内核);
        Brush_in(); return 1;
    }
    if (strncmp(kernel_version, "4.19.81", 7) == 0) {
        printf("[+] 请手动放入 4.19.81 驱动，文件名为“驱动.ko”\n");
        Brush_in(); return 1;
    }
    if (strncmp(kernel_version, "4.19.113", 8) == 0) {
        printf("检测到多个 4.19.113 驱动，请手动选择并命名为“驱动.ko”\n");
        printf("1.驱动4.19.113(1)\n2.驱动4.19.113(2)\n请输入序号：");
        scanf("%d", &NianChuan内核);
        Brush_in(); return 1;
    }
    if (strncmp(kernel_version, "4.19.157", 8) == 0) {
        printf("检测到多个 4.19.157 驱动，请手动选择并命名为“驱动.ko”\n");
        printf("1.内核4.19.157(1)\n2.内核4.19.157(2)\n3.内核4.19.157(OPPO Realme 一加)\n请输入序号：");
        scanf("%d", &NianChuan内核);
        Brush_in(); return 1;
    }
    if (strncmp(kernel_version, "4.19.191", 8) == 0) {
        printf("检测到多个 4.19.191 驱动，请手动选择并命名为“驱动.ko”\n");
        printf("1.内核4.19.191-note12pro-A13\n2.内核4.19.191-ColorOS-A13(OPPO Realme 一加)\n请输入序号：");
        scanf("%d", &NianChuan内核);
        Brush_in(); return 1;
    }
    if (strncmp(kernel_version, "6.1", 3) == 0) {
        printf("[+] 请手动放入 6.1 驱动，文件名为“驱动.ko”\n");
        Brush_in(); return 1;
    }
    if (strncmp(kernel_version, "5.4.210", 7) == 0) {
        printf("[+] 请手动放入 5.4.210 驱动，文件名为“驱动.ko”\n");
        Brush_in(); return 1;
    }
    if (strncmp(kernel_version, "5.4.233", 7) == 0) {
        printf("检测到多个 5.4.233 驱动，请手动选择并命名为“驱动.ko”\n");
        printf("1.驱动5.4[a]\n2.驱动5.4[b]\n3.驱动5.4[c]\n4.驱动5.4[d]-ColorOS-A14(OPPO Realme 一加)\n请输入序号：");
        scanf("%d", &NianChuan内核);
        Brush_in(); return 1;
    }
    if (strncmp(kernel_version, "5.4.61", 6) == 0) {
        printf("[+] 请手动放入 5.4.61 驱动，文件名为“驱动.ko”\n");
        Brush_in(); return 1;
    }
    if (strncmp(kernel_version, "5.4.86", 6) == 0) {
        printf("[+] 请手动放入 5.4.86 驱动，文件名为“驱动.ko”\n");
        Brush_in(); return 1;
    }
    if (strncmp(kernel_version, "5.4.147", 7) == 0) {
        printf("[+] 请手动放入 5.4.147 驱动，文件名为“驱动.ko”\n");
        Brush_in(); return 1;
    }
    if (strncmp(kernel_version, "5.10", 4) == 0) {
        驱动5点10(); return 1;
    }
    if (strncmp(kernel_version, "5.15", 4) == 0) {
        printf("[+] 请手动放入 5.15 驱动，文件名为“驱动.ko”\n");
        Brush_in(); return 1;
    }

    printf("\033[31m[-] 未适配当前内核 %s，请手动准备驱动\033[0m\n", kernel_version);
    return -1;
}

/* ---------- 入口 ---------- */
int 开始刷入驱动()
{
    printf("\n[+] 开始刷入内核\n");
    const char *dir = "/sdcard/NianChuan内核";
    struct stat st;
    if (stat(dir, &st) != 0) system("mkdir /sdcard/NianChuan内核");

    printf("\033[32;1m\nNianChuan内核提醒您:请注意演戏切勿乱杀\033[0m\n");

    int ret = install();          // 不再 exit
    if (ret == 1) {
        printf("\033[32m[+] 刷入流程结束，继续执行程序\033[0m\n");
    } else {
        printf("\033[33m[-] 刷入失败或跳过，继续执行程序\033[0m\n");
    }
    return ret;
}

#endif // 内置驱动例子_H